#ifndef DESENHO_H
#define DESENHO_H


class Desenho
{
public:
    Desenho();
};

#endif // DESENHO_H