#ifndef ARQUIVO_H
#define ARQUIVO_H


class Arquivo
{
public:
    Arquivo();
};

#endif // ARQUIVO_H
