#ifndef FORMA_H
#define FORMA_H


class Forma
{
public:
    Forma();
    //virtual ~Forma();

    virtual void pintar()=0;

};

#endif // FORMA_H
