#include "forma.h"

Forma::Forma()
{

}
