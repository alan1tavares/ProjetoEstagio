#ifndef MALHA_H
#define MALHA_H

#include "forma.h"

class Malha : public Forma
{
public:
    Malha();
};

#endif // MALHA_H
