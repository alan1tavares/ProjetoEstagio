#include "desenho.h"

Desenho::Desenho()
{

}
