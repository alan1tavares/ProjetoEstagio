#include "arquivo.h"

Arquivo::Arquivo()
{

}
