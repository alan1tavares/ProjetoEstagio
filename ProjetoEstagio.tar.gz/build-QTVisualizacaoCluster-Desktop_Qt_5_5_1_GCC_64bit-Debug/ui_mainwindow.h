/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>
#include "glpainel.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionCarregar_arquivo;
    QAction *actionSair;
    QAction *actionManual;
    QAction *actionSobre;
    QWidget *centralWidget;
    GLPainel *widget;
    QGroupBox *groupBoxMalha;
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox;
    QCheckBox *checkBox_3;
    QGroupBox *groupBoxEixos;
    QGridLayout *gridLayout_2;
    QSpacerItem *verticalSpacer_2;
    QCheckBox *checkBoxEixoY;
    QCheckBox *checkBoxEixoX;
    QCheckBox *checkBoxEixoZ;
    QGroupBox *groupBoxRotacao;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBoxTranslacao;
    QGridLayout *gridLayout_4;
    QLabel *labelX;
    QLabel *labelY;
    QLabel *labelZ;
    QMenuBar *menuBar;
    QMenu *menuArquivo;
    QMenu *menuSobre;
    QMenu *menuSobre_2;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(721, 501);
        actionCarregar_arquivo = new QAction(MainWindow);
        actionCarregar_arquivo->setObjectName(QStringLiteral("actionCarregar_arquivo"));
        actionSair = new QAction(MainWindow);
        actionSair->setObjectName(QStringLiteral("actionSair"));
        actionSair->setCheckable(false);
        actionManual = new QAction(MainWindow);
        actionManual->setObjectName(QStringLiteral("actionManual"));
        actionSobre = new QAction(MainWindow);
        actionSobre->setObjectName(QStringLiteral("actionSobre"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        widget = new GLPainel(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 10, 561, 341));
        widget->setStyleSheet(QStringLiteral(""));
        groupBoxMalha = new QGroupBox(centralWidget);
        groupBoxMalha->setObjectName(QStringLiteral("groupBoxMalha"));
        groupBoxMalha->setGeometry(QRect(590, 10, 121, 101));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        font.setWeight(75);
        groupBoxMalha->setFont(font);
        groupBoxMalha->setStyleSheet(QLatin1String("border-width: 1px;\n"
"border-style: solid;"));
        gridLayout = new QGridLayout(groupBoxMalha);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 0, 1, 1);

        checkBox_2 = new QCheckBox(groupBoxMalha);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        checkBox_2->setStyleSheet(QLatin1String("border-width: 0px;\n"
"font-weight: nomal;"));

        gridLayout->addWidget(checkBox_2, 3, 0, 1, 1);

        checkBox = new QCheckBox(groupBoxMalha);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setStyleSheet(QLatin1String("border-width: 0px;\n"
"font-weight: nomal;"));

        gridLayout->addWidget(checkBox, 2, 0, 1, 1);

        checkBox_3 = new QCheckBox(groupBoxMalha);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));
        checkBox_3->setStyleSheet(QLatin1String("border-width: 0px;\n"
"font-weight: nomal;"));

        gridLayout->addWidget(checkBox_3, 4, 0, 1, 1);

        groupBoxEixos = new QGroupBox(centralWidget);
        groupBoxEixos->setObjectName(QStringLiteral("groupBoxEixos"));
        groupBoxEixos->setGeometry(QRect(590, 130, 121, 101));
        groupBoxEixos->setFont(font);
        groupBoxEixos->setStyleSheet(QLatin1String("border-width: 1px;\n"
"border-style: solid;"));
        gridLayout_2 = new QGridLayout(groupBoxEixos);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_2, 1, 0, 1, 1);

        checkBoxEixoY = new QCheckBox(groupBoxEixos);
        checkBoxEixoY->setObjectName(QStringLiteral("checkBoxEixoY"));
        checkBoxEixoY->setStyleSheet(QLatin1String("border-width: 0px;\n"
"font-weight: nomal;"));
        checkBoxEixoY->setChecked(false);

        gridLayout_2->addWidget(checkBoxEixoY, 3, 0, 1, 1);

        checkBoxEixoX = new QCheckBox(groupBoxEixos);
        checkBoxEixoX->setObjectName(QStringLiteral("checkBoxEixoX"));
        checkBoxEixoX->setEnabled(true);
        checkBoxEixoX->setAcceptDrops(false);
        checkBoxEixoX->setAutoFillBackground(false);
        checkBoxEixoX->setStyleSheet(QLatin1String("border-width: 0px;\n"
"font-weight: nomal;"));
        checkBoxEixoX->setChecked(false);

        gridLayout_2->addWidget(checkBoxEixoX, 2, 0, 1, 1);

        checkBoxEixoZ = new QCheckBox(groupBoxEixos);
        checkBoxEixoZ->setObjectName(QStringLiteral("checkBoxEixoZ"));
        checkBoxEixoZ->setStyleSheet(QLatin1String("border-width: 0px;\n"
"font-weight: nomal;"));
        checkBoxEixoZ->setChecked(false);

        gridLayout_2->addWidget(checkBoxEixoZ, 4, 0, 1, 1);

        groupBoxRotacao = new QGroupBox(centralWidget);
        groupBoxRotacao->setObjectName(QStringLiteral("groupBoxRotacao"));
        groupBoxRotacao->setGeometry(QRect(30, 360, 161, 81));
        groupBoxRotacao->setFont(font);
        groupBoxRotacao->setStyleSheet(QLatin1String("border-width: 1px;\n"
"border-style: solid;"));
        gridLayout_3 = new QGridLayout(groupBoxRotacao);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        groupBoxTranslacao = new QGroupBox(centralWidget);
        groupBoxTranslacao->setObjectName(QStringLiteral("groupBoxTranslacao"));
        groupBoxTranslacao->setGeometry(QRect(220, 360, 141, 81));
        groupBoxTranslacao->setFont(font);
        groupBoxTranslacao->setStyleSheet(QLatin1String("border-width: 1px;\n"
"border-style: solid;"));
        gridLayout_4 = new QGridLayout(groupBoxTranslacao);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        labelX = new QLabel(centralWidget);
        labelX->setObjectName(QStringLiteral("labelX"));
        labelX->setGeometry(QRect(630, 260, 55, 17));
        labelY = new QLabel(centralWidget);
        labelY->setObjectName(QStringLiteral("labelY"));
        labelY->setGeometry(QRect(630, 290, 55, 17));
        labelZ = new QLabel(centralWidget);
        labelZ->setObjectName(QStringLiteral("labelZ"));
        labelZ->setGeometry(QRect(630, 320, 55, 17));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 721, 27));
        menuArquivo = new QMenu(menuBar);
        menuArquivo->setObjectName(QStringLiteral("menuArquivo"));
        menuSobre = new QMenu(menuBar);
        menuSobre->setObjectName(QStringLiteral("menuSobre"));
        menuSobre_2 = new QMenu(menuBar);
        menuSobre_2->setObjectName(QStringLiteral("menuSobre_2"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuArquivo->menuAction());
        menuBar->addAction(menuSobre->menuAction());
        menuBar->addAction(menuSobre_2->menuAction());
        menuArquivo->addAction(actionCarregar_arquivo);
        menuArquivo->addAction(actionSair);
        menuSobre_2->addAction(actionManual);
        menuSobre_2->addAction(actionSobre);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionCarregar_arquivo->setText(QApplication::translate("MainWindow", "Carregar arquivo", 0));
        actionSair->setText(QApplication::translate("MainWindow", "Sair", 0));
        actionManual->setText(QApplication::translate("MainWindow", "Manual", 0));
        actionSobre->setText(QApplication::translate("MainWindow", "Sobre", 0));
#ifndef QT_NO_TOOLTIP
        groupBoxMalha->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        groupBoxMalha->setTitle(QApplication::translate("MainWindow", "Malhas", 0));
        checkBox_2->setText(QApplication::translate("MainWindow", "xz", 0));
        checkBox->setText(QApplication::translate("MainWindow", "xy", 0));
        checkBox_3->setText(QApplication::translate("MainWindow", "yz", 0));
#ifndef QT_NO_TOOLTIP
        groupBoxEixos->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        groupBoxEixos->setTitle(QApplication::translate("MainWindow", "Eixos", 0));
        checkBoxEixoY->setText(QApplication::translate("MainWindow", "y", 0));
        checkBoxEixoX->setText(QApplication::translate("MainWindow", "x", 0));
        checkBoxEixoZ->setText(QApplication::translate("MainWindow", "z", 0));
#ifndef QT_NO_TOOLTIP
        groupBoxRotacao->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        groupBoxRotacao->setTitle(QApplication::translate("MainWindow", "Rota\303\247\303\243o", 0));
#ifndef QT_NO_TOOLTIP
        groupBoxTranslacao->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        groupBoxTranslacao->setTitle(QApplication::translate("MainWindow", "Transla\303\247\303\243o", 0));
        labelX->setText(QApplication::translate("MainWindow", "<html><head/><body><p>x</p></body></html>", 0));
        labelY->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">y</span></p></body></html>", 0));
        labelZ->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">z</span></p></body></html>", 0));
        menuArquivo->setTitle(QApplication::translate("MainWindow", "Arquivo", 0));
        menuSobre->setTitle(QApplication::translate("MainWindow", "Exibir", 0));
        menuSobre_2->setTitle(QApplication::translate("MainWindow", "Ajuda", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
